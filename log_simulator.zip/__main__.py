import log_generator

log_generator.main()
